# Neighborly Cleaning by Michelle — Website

## Preview locally
1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Double-click `index.html` to open it in a browser, or right-click it and choose your browser.
3. Test the navigation, phone link, email link, and estimate form.

The estimate form uses a no-cost `mailto:` workflow. It does not send data to a server: clicking **Send Request** opens the visitor's email application with the form details filled in, and the visitor must review and send the email.

## Publish later
No domain, paid service, or public hosting is configured by this package.

When you're ready to publish, you can upload the three website files to a static web host such as GitHub Pages, Netlify, or another hosting provider. A custom domain can be connected later if desired. Review the host's current pricing before choosing a paid option.

## Notes
- Business information and service areas are based on the supplied details.
- No prices, guarantees, licenses, certifications, or other credentials have been invented.
- The visual design follows the supplied reference image: bright white/light-blue sections, deep blue typography, rounded cards, prominent estimate CTA, and cleaning-related photography.
- Photography is loaded from Unsplash URLs, so an internet connection is needed for those images to appear.
